package com.NETS.dao;

import com.NETS.connect.ConnectionDB;
import com.NETS.models.Cliente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author caio.lavorato
 */
public class DaoCliente {

     public static Cliente inserirCliente(Cliente cliente) throws SQLException{
        
        Long id_endereco = DaoEndereco.inserirEndereco(cliente.getEndereco());
        String query = "INSERT INTO cliente (nome, sobrenome, cpf, sexo, dt_nascimento, id_endereco) VALUES (?,?,?,?,?,?)";
        
        try (Connection conn = ConnectionDB.getConnection();
                PreparedStatement stmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
        
            stmt.setString(1, cliente.getNome());
            stmt.setString(2, cliente.getSobrenome());
            stmt.setString(3, cliente.getCpf());
            stmt.setString(4, cliente.getSexo());
            
            java.sql.Date data = new java.sql.Date(cliente.getDtNascimento().getTime());
            stmt.setDate(5, data);
            stmt.setLong(6, id_endereco);
             
            stmt.executeUpdate();
             
            ResultSet generatedKeys = stmt.getGeneratedKeys();
            if (generatedKeys.next()) {
                cliente.setId(generatedKeys.getLong(1));
            }
        }
        return cliente;
    }
    
}
